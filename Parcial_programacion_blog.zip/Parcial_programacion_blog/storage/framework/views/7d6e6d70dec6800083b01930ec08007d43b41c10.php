<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h1>Login</h1>
<br>

<input type="text" name="email" placeholder="Ingresa tu Email">
<br>
<input type="password" name="Pasword" placeholder="Ingresa tu Password">
<br>
<button type="submit">Enviar</button>
<br>
<br>

<h1>¿no tienes Usuario?</h1>
<br>


<h1>Registrate</h1>
<br>
<input type="text" name="ingresa_nombre" placeholder="Ingresa tu nombre de usuario">
<br>
<input type="text" name="ingresa_email" placeholder="Ingresa tu email">
<br>
<input type="password" name="ingresa_password" placeholder="Ingresa tu password">
<br>
<button type="submit">Enviar</button>



</body>
</html><?php /**PATH C:\Users\iangr\OneDrive\Documentos\Programacion\parcial-de-programacion\Parcial_programacion_blog\resources\views/home.blade.php ENDPATH**/ ?>